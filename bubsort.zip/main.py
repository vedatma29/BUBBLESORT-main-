a=[19,9,12,4,17]
print("the given array is:")
for i in range(len(a)):
    print("%d" %a[i])

for i in range(len(a)):
   
    
    for j in range(len(a)-1):
        
        if a[j]>a[j+1]:
            
            a[j],a[j+1]=a[j+1],a[j]
            
    
print("sorted array is-")
for i in range(len(a)):
    print("%d" %a[i])